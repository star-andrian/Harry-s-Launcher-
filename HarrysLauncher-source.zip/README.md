# Harry's Launcher

Native Android launcher starter project for Android 10+ (API 29+), built with Kotlin and Jetpack Compose.

## First milestone
- Android HOME launcher support.
- Installed-app discovery.
- Searchable app drawer.
- One-tap app launching.
- Initial home-screen layout and dark woodland-inspired palette.
- GitHub Actions workflow to build a debug APK.

## Upload from your phone
1. Upload `HarrysLauncher-source.zip` to the root of your GitHub repository.
2. Also upload the separate workflow file to `.github/workflows/android-apk.yml` (create the folders if needed).
3. Commit both files to the `main` branch.
4. Open the repository's **Actions** tab and open **Build Harry's Launcher APK**.
5. When the run finishes successfully, download the `HarrysLauncher-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. Allow your browser or file manager to install unknown apps if Android asks.
7. Set it as your Home app in Android Settings → Apps → Default apps → Home app.

The workflow automatically extracts the source ZIP before building.

## Local build
Requires JDK 17, Android SDK Platform 36, and Gradle 8.13:
```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Scope
This is the first installable foundation, not the full feature-complete launcher. A visual customization editor, widgets, gestures, icon packs, folders, profiles, backup/restore, and advanced animations belong to later milestones.
