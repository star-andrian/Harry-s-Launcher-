package com.flux.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class LaunchableApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HarrysLauncherTheme { LauncherScreen() } }
    }
}

@Composable
private fun HarrysLauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFB7F36B),
            background = Color(0xFF10130F),
            surface = Color(0xFF1A2018),
            onBackground = Color(0xFFF2F5ED),
            onSurface = Color(0xFFF2F5ED)
        ),
        content = content
    )
}

@Composable
private fun LauncherScreen() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var drawerOpen by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(emptyList<LaunchableApp>()) }

    fun loadApps() {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        apps = resolved.mapNotNull { info ->
            val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
            if (packageName == context.packageName) return@mapNotNull null
            LaunchableApp(
                label = info.loadLabel(pm).toString(),
                packageName = packageName,
                icon = info.loadIcon(pm)
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    LaunchedEffect(Unit) { loadApps() }

    val filtered = remember(apps, query) {
        apps.filter { it.label.contains(query, ignoreCase = true) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF10130F))
            .padding(horizontal = 22.dp, vertical = 26.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("HARRY'S", color = Color(0xFFB7F36B), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Launcher", color = Color(0xFFF2F5ED), fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
                }
                Surface(
                    modifier = Modifier.size(46.dp).clip(CircleShape).clickable {
                        context.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    },
                    color = Color(0xFF20291C),
                    shape = CircleShape
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Settings, contentDescription = "Launcher settings", tint = Color(0xFFB7F36B))
                    }
                }
            }

            Spacer(Modifier.height(28.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1A2018),
                shape = RoundedCornerShape(22.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 17.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFB7F36B))
                    Spacer(Modifier.size(12.dp))
                    Text(
                        "Search your apps",
                        color = Color(0xFF9AA493),
                        fontSize = 15.sp,
                        modifier = Modifier.weight(1f).clickable { drawerOpen = true }
                    )
                    Icon(Icons.Default.Apps, contentDescription = "Open app drawer", tint = Color(0xFF9AA493),
                        modifier = Modifier.clickable { drawerOpen = true })
                }
            }

            Spacer(Modifier.height(24.dp))
            Text("YOUR SPACE", color = Color(0xFF899481), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f),
                color = Color(0xFF171D15),
                shape = RoundedCornerShape(28.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("A calmer home screen.", color = Color(0xFFF2F5ED), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text("Your apps are one tap away.", color = Color(0xFF9AA493), fontSize = 14.sp)
                        Spacer(Modifier.height(22.dp))
                        Surface(
                            modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable { drawerOpen = true },
                            color = Color(0xFFB7F36B),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("OPEN APP DRAWER", color = Color(0xFF17200F), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 13.dp), letterSpacing = 1.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val favourites = apps.take(4)
                favourites.forEach { app ->
                    AppIcon(app = app, onClick = { launchApp(context, app.packageName) })
                }
                if (favourites.isEmpty()) {
                    Text("Apps will appear here after loading", color = Color(0xFF899481), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        AnimatedVisibility(
            visible = drawerOpen,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF10130F),
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(top = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("All apps", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("CLOSE", color = Color(0xFFB7F36B), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { drawerOpen = false }.padding(10.dp))
                    }
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Find an app") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        shape = RoundedCornerShape(18.dp)
                    )
                    Spacer(Modifier.height(14.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(filtered, key = { it.packageName }) { app ->
                            AppIcon(app = app, onClick = { launchApp(context, app.packageName) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppIcon(app: LaunchableApp, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        androidx.compose.foundation.Image(
            bitmap = remember(app.packageName) {
                val drawable = app.icon
                val bitmap = android.graphics.Bitmap.createBitmap(96, 96, android.graphics.Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bitmap)
                drawable.setBounds(0, 0, 96, 96)
                drawable.draw(canvas)
                androidx.compose.ui.graphics.asImageBitmap(bitmap)
            },
            contentDescription = app.label,
            modifier = Modifier.size(48.dp)
        )
        Spacer(Modifier.height(6.dp))
        Text(app.label, color = Color(0xFFE9EEE3), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

private fun launchApp(context: android.content.Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
